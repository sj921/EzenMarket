package com.ezen.ezenmarket.user.service;

import javax.servlet.http.HttpServletRequest;

public interface UserService {
	
	public String getUserId(HttpServletRequest req);
	
}
